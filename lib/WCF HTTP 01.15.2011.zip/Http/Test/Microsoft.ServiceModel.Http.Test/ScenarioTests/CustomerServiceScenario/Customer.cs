﻿// <copyright>
//   Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>

namespace System.ServiceModel.Http.Test.ScenarioTests
{
    public class Customer
    {
        public string Name { get; set; }

        public int Id { get; set; }
    }
}

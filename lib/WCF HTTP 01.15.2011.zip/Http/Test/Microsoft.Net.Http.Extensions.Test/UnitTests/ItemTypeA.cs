﻿// <copyright>
//   Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>

namespace Microsoft.Net.Http.Extensions.Test
{
    public class ItemTypeA
    {        
        public string Name { get; set; }
    }
}